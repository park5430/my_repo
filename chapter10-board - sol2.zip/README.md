# chapter10-board

10장 게시판 만들기 예제

> 편의를 위해 모든 예제에서 개발 IDE는 VS Code를 사용한다고 가정합니다.

## 실행 방법

VS Code의 Live Server extension를 사용하여 index.html 파일을 실행합니다.

![liveserver](https://user-images.githubusercontent.com/37766175/136686654-a4310f89-625e-456b-b1d5-5258bfa57c59.png)

async function getUser() { // 사용자 정보를 가져오는 함수
  try {
    // 사용자 정보를 서버에서 가져옵니다.
    const res = await axios.get('/users');
    const users = res.data; // 서버 응답에서 사용자 데이터를 추출합니다.
    const list = document.getElementById('list'); // 화면에서 사용자 리스트를 표시할 요소를 찾습니다.
    list.innerHTML = ''; // 리스트를 초기화합니다.

    // 각 사용자에 대해 반복하며 화면에 표시하고 이벤트를 연결합니다.
    Object.keys(users).map(function (key) {
      const userDiv = document.createElement('div'); // 사용자 정보를 표시할 div 요소 생성
      const span = document.createElement('span'); // 사용자 이름을 표시할 span 요소 생성
      span.textContent = users[key]; // span에 사용자 이름 설정

      const edit = document.createElement('button'); // 수정 버튼 생성
      edit.textContent = '수정'; // 버튼 텍스트 설정
      edit.addEventListener('click', async () => { // 수정 버튼 클릭 이벤트 리스너
        const name = prompt('바꿀 이름을 입력하세요'); // 사용자에게 새 이름을 입력받음
        if (!name) {
          return alert('이름을 반드시 입력하셔야 합니다');
        }
        try {
          // 서버로 수정된 이름을 전송하여 사용자 정보를 업데이트합니다.
          await axios.put('/user/' + key, { name });
          getUser(); // 수정 후 사용자 정보를 다시 가져옵니다.
        } catch (err) {
          console.error(err);
        }
      });

      const remove = document.createElement('button'); // 삭제 버튼 생성
      remove.textContent = '삭제'; // 버튼 텍스트 설정
      remove.addEventListener('click', async () => { // 삭제 버튼 클릭 이벤트 리스너
        try {
          // 서버로 사용자를 삭제 요청합니다.
          await axios.delete('/user/' + key);
          getUser(); // 삭제 후 사용자 정보를 다시 가져옵니다.
        } catch (err) {
          console.error(err);
        }
      });

      // 생성한 요소들을 사용자 리스트에 추가합니다.
      userDiv.appendChild(span);
      userDiv.appendChild(edit);
      userDiv.appendChild(remove);
      list.appendChild(userDiv);

      console.log(res.data); // 서버에서 받은 사용자 데이터를 콘솔에 출력합니다.
    });
  } catch (err) {
    console.error(err);
  }
}

window.onload = getUser; // 화면이 로딩될 때 getUser 함수를 호출합니다.

// 폼 제출(submit) 시 실행
document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault(); // 기본 제출 동작을 막습니다.
  const name = e.target.username.value; // 폼에서 입력한 사용자 이름을 가져옵니다.
  if (!name) {
    return alert('이름을 입력하세요');
  }
  try {
    // 서버로 새 사용자 정보를 전송합니다.
    await axios.post('/user', { name });
    getUser(); // 사용자 정보를 다시 가져옵니다.
  } catch (err) {
    console.error(err);
  }
  e.target.username.value = ''; // 입력 필드를 초기화합니다.
});

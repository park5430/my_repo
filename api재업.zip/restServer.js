const http = require('http'); // HTTP 모듈 불러오기
const fs = require('fs').promises; // 파일 시스템 모듈 불러오기 (Promise 기반)

const users = {}; // 데이터 저장용 객체

// HTTP 서버 생성
http.createServer(async (req, res) => {
  try {
    if (req.method === 'GET') { // GET 요청 처리
      if (req.url === '/') { // 루트 경로에 대한 처리
        const data = await fs.readFile('./restFront.html'); // restFront.html 파일 읽기
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(data);
      } else if (req.url === '/about') { // /about 경로에 대한 처리
        const data = await fs.readFile('./about.html'); // about.html 파일 읽기
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(data);
      } else if (req.url === '/users') { // /users 경로에 대한 처리
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify(users)); // 사용자 데이터를 JSON 형태로 응답
      } else {
        try {
          const data = await fs.readFile(`.${req.url}`); // 다른 경로 요청에 대한 처리
          return res.end(data);
        } catch (err) {
          // 주소에 해당하는 라우트를 찾지 못했을 경우 404 Not Found 에러 발생
        }
      }
    } else if (req.method === 'POST') { // POST 요청 처리
      if (req.url === '/user') { // /user 경로에 대한 처리
        let body = '';
        // 요청의 본문(body)를 스트림 형식으로 받음
        req.on('data', (data) => {
          body += data;
        });
        // 요청의 본문(body)를 모두 받은 후 실행
        return req.on('end', () => {
          console.log('POST 본문(Body):', body);
          const { name } = JSON.parse(body); // JSON 형식의 본문을 파싱하여 사용자 이름 추출
          const id = Date.now();
          users[id] = name; // 사용자 정보를 저장
          res.writeHead(201, { 'Content-Type': 'text/plain; charset=utf-8' });
          res.end('ok');
        });
      }
    } else if (req.method === 'PUT') { // PUT 요청 처리
      if (req.url.startsWith('/user/')) { // /user/로 시작하는 경로에 대한 처리
        const key = req.url.split('/')[2]; // 경로에서 사용자 키(key) 추출
        let body = '';
        req.on('data', (data) => {
          body += data;
        });
        return req.on('end', () => {
          console.log('PUT 본문(Body):', body);
          users[key] = JSON.parse(body).name; // 사용자 정보 수정
          res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
          return res.end('ok');
        });
      }
    } else if (req.method === 'DELETE') { // DELETE 요청 처리
      if (req.url.startsWith('/user/')) { // /user/로 시작하는 경로에 대한 처리
        const key = req.url.split('/')[2]; // 경로에서 사용자 키(key) 추출
        delete users[key]; // 사용자 정보 삭제
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('ok');
      }
    }
    res.writeHead(404); // 위의 조건에 해당하지 않으면 404 Not Found 응답
    return res.end('NOT FOUND');
  } catch (err) {
    console.error(err);
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end(err.message);
  }
})
  .listen(8082, () => {
    console.log('8082번 포트에서 서버 대기 중입니다');
  });

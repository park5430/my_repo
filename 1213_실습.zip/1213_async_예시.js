// async, await 구문의 사용법

async function myName() {
    return "andy";
}

console.log(myName());
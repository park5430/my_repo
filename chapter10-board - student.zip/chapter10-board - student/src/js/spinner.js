export function createSpinner(parent) {
  const spinnerAreaEl = ???;
  const imageEl = ???;
  imageEl.alt = 'spinner';
  imageEl.src = './src/image/spinner.gif';

  spinnerAreaEl.???(???);
}

// 콜백함수 예시
const DB = [];

function register(user) {
  return saveDB(user, function (user) {
    return sendEmail(user, function (user) {
      return getResult(user);
    });
  });
}

function saveDB(user, callback) {
    DB.push(user); 
    console.log(`${user.name} 데이터가 DB에 잘 저장되었습니다`);
    return callback(user);
}

function sendEmail(user, callback) {
    console.log(`${user.email} 데이터가 전송되었습니다`);
    return callback(user);
}

function getResult(user) {
    return `성공!!! ${user.name}`
}

// 이 코드를 테스트 하기 위한 샘플데이터를 정의하고 함수를 실행하는 명령어
const result = register({email: "andy@test.com", password: "1234", name: "andy"})
console.log(result);

// 콜백함수는 단계별로 엮여 있어서 디버그가 힘들다
// 미래 특정 시점에 실행하는 객체로 promise를 사용한다
// promise는 이행, 거절, 대기 3가지 상태를 가진다

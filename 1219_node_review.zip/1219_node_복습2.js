// curl 기억하실거에요.
// 서버를 구동했을 때 나오는 세부적인 상태를 진단하는 툴입니다.
// curl의 옵션 중 자주 쓰이는 것이 -X 입니다.
// curl -X GET localhost:3000 이런식으로 사용이 되지요.
// 포스팅 글을 없애고 이를 테스트 하는 방법은
// curl -X DELETE localhost:3000/posts/2 
// 성공하면 데이터가 삭제됩니다.  

// package.json 파일을 만드는 이유와 방법을 설명해볼 사람?
// 저희 sql 연동 예제를 기억하실겁니다.
// morgan, sequelize, express, nodemon, nunjucks... 많죠?
// 저 사용 패키지 리스트가 길어지면 일일히 메모장에 쓸까요?
// 아 그리고, 파일도 수십 수백개 될건데 뭐가 주 실행 스크립트인지
// 그거 포스트잇에 붙일까요? ㅋ
// package.json에 내가 필요한 모든 사용 패키지 버전을 기록하고
// 주 실행스크립트를 지정해서 버전관리, 패키지관리를 돕는 파일입니다.
// 사용방법은 git bash 가셔서 npm init -y 하면 됩니다.
// 심심한 사람들 해보세요 ㅋ
// package.json이 올바르게 모든 정보를 가지고 있다 가정 할때,
// morgan, sequelize, express, nodemon, nunjucks... 한번에 설치하는 방법이 잇죠
// npm install 하면 되죠? 그럼 다 깔려요. 지정폴더에
// 그리고 npm start하면 프로그램 열립니다.
// 그리고 혹시나 패키지의 업뎃이 필요하면
// npm update 하면 됩니다. 깔린친구들 다 찾아서 업뎃해줌

// npm uninstall 이러면 다 날아가겟죠?
// npm uninstall express 이렇게 특정해주세요~

// package json의 추가적인 사용법에 대해 알아 봅시다.
// 여러개의 명령어를 등록해서 json의 키값을 입력하면 해당 기능이 실행됩니다.

// 아래의 json파일이 있다 가정합시다.

{
    "name": "test-scripts",
    "version": "1.0.0",
    "scripts": {
      "test": "echo 'test Node.js'",
      "stop": "echo 'stop Node.js'",
      "start": "echo 'start Node.js'",
      "restart": "echo 'restart Node.js'"
    }
  }
// git bash가셔서 
// npm test, npm stop 이렇게 각각 입력하면
// test Node.js, stop Node.js 라고 출력됩니다


// 비동기, 프라미스, aync ㅎㅎ
// 서버의 특징은 비동기처리이다.
// 다음 명령어를 기다리지 않고 기능이 실행된다.
// 근데 문제는 url에서 정보를 읽는 중요한 기능을 기다리지않고
// 데이터가 없다는 식으로 사고를 친다.
// 비동기를 안쓰자니 또 특정 작업때문에 병목현상이 발생한다.
// 이를 해결하고자 하는 컨셉이 뭐다? 콜백
// 비유를 들면 커피숍 사장이 주문받고 청소, 설거지, 다른손님오더
// 이런 다른작업을 진행하지만, 내 커피가 완전히 준비되면
// 그때서야 나를 부른다. 
// 커피제조후에 나를 부르는 파트를 콜백함수 처리된 파트라 보면 된다.

// 콜백함수의 예시 (3단계 콜백함수)
// 회원가입 api호출 후 
// 1. 데이터베이스에 저장, 2. 이메일 송부, 3. 성공메세지 송부

const db = [];

function register(user) {
    return saveDB(user, function (user) {
return sendEmail(user, function (user) {
    return getResult(user);
})
    })
}

// 저희가 express 프레임워크를 왜 사용하는지  확인하겟습니다.
// 기본적인 node.js 라이브러리는 미들웨어, 템플릿 엔진, 요청을 받는 기능 등이 부족합니다.
// 파이썬 수업 오름차순 정렬 알고리즘 수업 기억하시나요?

// 모든 프로그램은 기본 ㅏ이썬으로 코딩가능합니다만, 매우 어렵죠?
// node.js도 마찬가지 입니다.
// express 사용 이유를 웹서버가 제공해야하는 기능으로 기능별 필요사항을 설명하겠습니다.

// 라우팅 = url요청을 함수와 매핑시켜주는 기능 (내 주소와 나의 웹서비스 관련 함수의 매칭)
// 정적파일 서비스 = 내가 준비한 css, 자바스크립트 등의 정적파일 컨트롤
// 템플릿 엔진 = 동적 웹페이지를 html을 사용해 생성하는 기능 (ejs 실습 기억하시죠?)
// 요청과 응답 데이터 다루기 = http요청을 추상화해 서버를 다루는 기능
// 미들웨어 = 요청과 응답사이 중간 결과를 처리하는 기능

// 위 기능을 기본 node.js에서 구현하려면 코딩이 복잡해 집니다. 
// 그래서 express 프레임워크같은 오픈소스를 사용합니다.

// 이러한 프레임워크 설치는 컴퓨터 전체에 설치하는 
// global 모드가 있고 특정폴더에 한정해서 설치한다 그랬죠?

// 특정폴더에 한정해서 설치하는게 장점이 있다 했는데 그거 기억하는사람?
// 프레임워크 별로 설치환경, 버전관리가 필요한 경우가 있습니다. <- 기억해주세요
// 글로벌로 설치하면 편한데, 다른 node.js환경을 구축해야 하는경우 컴퓨터를 또 사야합니다.
// 각 폴더가 독립된 환경이라면 컴터 안사도 되겠죠? 

// 이러한 node.js 패키지 관리툴을 npm (nodejs package manager)라고 합니다.
// you got it :)
// 기존 node js 대비 express 사용 서버 기본을 만들어 보시죠
// express 프레임워크 불러올라면 뭐한다 그랬죠?

// express를 부른 후에 express()를 실행해 주시면 좋습니다.
// 그리고 포트번호를 변수처리하는 것도 나쁘진 않습니다.

const express = require("express"); 
const app = express();
const port = 3000;
// 아까 말씀드린대로 express는 경로처리 장점이 있습니다. 후속 코드를 보시죠
// 어제 친구는 url 모듈을 따로 불러와서 또 추가적인 경로설정이 필요했죠
// 어제 코드 함게 보시죠. 세부경로를 기본적으로 지원해주죠?
// express에게 감사~
app.get('/', (req,res) => {
res.set({"Content-Type": "text/html; charset=utf-8"});
res.end('안녕 express');
});

app.listen(port, () => {
    console.log(`서버를 시작하라: ${port}를 사용하고`)
});

// 이제 express를 이용해서 어제 세부페이지 코딩을 다시 진행해 보시죠
// 직접 해보시는게 제일 좋아요.
const express = require("express");
const url = require("url");
const app = express();
const port = 3000;
// 지금의 코딩을 어제 예제와 비교해 보세요
// 급하게 화면 넘기실 필요없어요. 어제 if절이랑 뭐가 다른지 보세요.
// 코드 리팩토링의 과정 없이 정리가 되었죠?

app.get('/', (_, res) => res.end("home"));
app.get('/user', user);
app.get('/feed', feed);
function user(req,res) {
    const user = url.parse(req.url, true).query;
    res.end("[user] name : andy, age: 30");
}
function feed(_,res) {
    res.end(`<ul>
    <li>picture1</li>
    <li>picture2</li>
    <li>picture3</li>
  </ul>
  `);
}
app.listen(port, () => {
    console.log(`서버를 시작하라: ${port}를 사용하고`)
});

// api 뜻 기억하는사람?
// application programming interface
// 프로그램에서 다른 프로그램 기능을 사용하게 해주는 규칙

// api에서 저희가 사용하는 기능은 sql의 CRUD 구현기능이겠죠?
// GET, POST, DELETE 등이 있습니다. 이미 친숙하실거라 생각

// 그럼 API 규칙에 맞게 간단한 서버를 구현해 보시죠

const express = require("express");
const app = express();
const port = 3000;
// 게시글 리스트에 사용할 빈 데이터베이스를 할당했죠
let posts = [];
// express의 json 미들웨어를 사용합니다.

app.use(express.json());
// 아래 명령어의 뜻은 key=value의 형태의 데이터를 해석해준단 말
// officially, its saying: application/x-www-form-urlencoded
// 즉, json형식의 데이터가 오면 데이터를 해석해달라는 명령입니다.
app.use(express.urlencoded({extended: true}));

app.get('/', (req,res) =>{
    res.json(posts);
})
// 입력된 데이터의 저장 
app.post('/posts', (req,res) =>{
    const {title, name, text} = req.body;
})
// 새로운 post데이터 추가
posts.push({id: posts.length +1, 
    title, name, text, createDT: Date()});
res.json({title, name, text})

app.delete('/posts/:id', (req,res) =>{
    const id = req.params.id;
    const filteredPosts = posts.filter((post) => post.id !== +id);
    // 글 데이터 삭제 여부의 확인
    const isLengthChanged = posts.length !== filteredPosts.length;
    // 글 삭제 이후 남은 글을 posts 변수에 저장
    posts = filteredPosts;
    // 게시글 삭제하면 ok로 응답한다.
    if(isLengthChanged) {
        res.json("ok");
        return;
    }
    res.json('not changed')
});

app.listen(port, () => {
    console.log(`서버를 시작하라: ${port}를 사용하고`)
});
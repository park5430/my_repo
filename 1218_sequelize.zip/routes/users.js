// SQL 테이블 생성, 키값의 설정 등이 담긴  
// USER, COMMENT 자바 스크립트를 불러온다.

const express = require('express');
const User = require('../models/user');
const Comment = require('../models/comment');

// express 라우터를 생성합니다.

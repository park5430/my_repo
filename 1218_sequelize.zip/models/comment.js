const Sequelize = require('sequelize');


module.exports = class Comment extends Sequelize.Model {
    static init(sequelize) {
        return super.init ({
            comment: {
                type: Sequelize.STRING(100),
                allowNull: false,
            },
            created_at: {
                type: Sequelize.DATE,
                allowNull: false,
                defaultValue: Sequelize.NOW,
            },
            commenter: {
                type: Sequelize.INTEGER,
                allowNull: false,
                reference: {
                    mode: 'user',
                    key: 'id',
                },
            },
        }, {
              //mysql에 필요한 조건을 지정해야함.
    sequelize,
    timestamps: false, //타임스탬프 자동생성 비활성화
    modelName: 'Comment',
    tableName: 'comments',
    paranoid: false, //소프트삭제 비활성화
    charset: 'utf8',
    collate: 'utf8_general_ci'  
        })
    }

    static associate(db) {
        // User 모델과 Comment 모델간의 일대다 관계설정
    db.Comment.hasMany(db.User, {foreignKey: 'commenter', targetKey: 'id'});
}
}

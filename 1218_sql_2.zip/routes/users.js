// SQL 테이블 생성, 키값의 설정 등이 담긴
// USER, COMMENT 자바 스크립트를 불러온다.

const express = require("express");
const User = require("../models/user");
const Comment = require("../models/comment");

// express 라우터를 생성합니다.
const router = express.Router();

// 서비스 주소(경로)에 따른 get & post 요청을 처리합니다.
// 미들웨어의 사용
router.route("/")
.get(async (req, res, next) => {
  try {
    // 모든 사용자 정보를 조회합니다.
    const users = await User.findAll();
    //조회된 사용자 정보를 JSON 형식으로 응답합니다.
    res.json(users);
  } catch (err) {
    console.error(err);
    next(err);
  }
})
.post(async (req,res,next) => {
    try{
        // 요청해서 받은 정보로 새로운 사용자를 생성합니다.
        // user라는 sql 테이블 자체가 사용자 데이터 관련이므로
        const user = await User.create({
            name: req.body.name,
            age: req.body.age,
            married: req.body.married,
        });
        //생성된 사용자 정보를 로그에 출력하고, 201(정상)상태로 응답합니다.
console.log(user);
res.status(201).json(user);
    }
    catch (err) {
        console.error(err);
        next(err);
    }
});

// 특정 사용자의 댓글을 조회하는 경로(라우트)를 정의합니다.
// 특정 사용자가 도데체 몇명이 올지 모르니까 
// 동적 컨텐츠가 됩니다. :이 사용될 시간입니다.
router.get('/:id/comments', async (req,res,next) => {
    try {

    }
    catch (err) {

    }
})


const express = require('express');
const {Comment} = require('../models');

const router = express.Router();

// 새로운 댓글을 생성하는 함수
router.post('/', async (req,res,next) => {
    try {
        const comment = await Comment.create({
            // 요청된 본문에서 사용자 id를 가져와서 댓글의 작성자로 설정
commenter: req.body.id,
// 요청된 본문에서 댓글내용을 가져와서 댓글 필드로 설정
comment: req.body.comment,
        });
        // 성공적으로 생성된 댓글을 응답합니다.
        console.log(comment);
        res.status(201).json(comment);
    }
    catch (err) {
        console.error(err);
        next(err);
    }
});
// 댓글을 업뎃하는 함수
router.route('/:id')
.patch(async (req,res,next) => {
try{
const result = await Comment.update({
    //요청 본문에서 새로운 댓글내용을 가져와서 업데이트 할 때
    comment: req.body.comment,
}, {
    // 주어진 id를 가진 댓글을 찾아서 업데이트
where: {id: req.params.id}
})
//업데이트 된 결과를 응답합니다
res.json(result);
}
catch (err) {
console.error(err);
next(err);
}
})
.delete(async (req,res,next) => {
    try{
        // 주어진 id를 가진 댓글을 삭제합니다.
const result = await Comment.destroy({where: {id: req.params.id}})
res.json(result);
    }
    catch (err) {
        console.error(err);
        next(err);
    }
});

module.exports = router;
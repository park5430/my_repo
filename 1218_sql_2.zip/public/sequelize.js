// 사용자 이름을 클릭 했을 때 댓글을 로딩하는 이벤트 리스너
document.querySelectorAll('#user-list tr').forEach((el) => {
    el.addEventListener('click', function() {
        //클릭한 테이블 행에서 첫번째 열(td) 내용을 가져온다.
        const id = el.querySelector('td').textContent;
// 해당 사용자의 댓글을 가져오는 함수 호출
        getComment(id);
    })
})




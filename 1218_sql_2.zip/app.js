const express = require('express');
const path = require('path');
const morgan = require('morgan');
const nunjucks = require('nunjucks');

const {sequelize} = require("./models");
const indexRouter = require("./routes");
const usersRouter = require("./routes/users");
const commentsRouter = require("./routes/comments");

const app = express();
// 포트번호를 지정하는데 특별한 환경변수 없으면 포트번호는 3001번
app.set('port', process.env.PORT || 3001);
// express 템플릿 엔진입니다. html파일을 읽어서 처리하는 기능입니다.
// 다만 nunjucks 가 선언되었으므로 
// 지금 html 파일은 express 산하 nunjucks 프레임워크에서 처리될 것
app.set('view engine', 'html')
// nunjucks 설정을 진행합니다. (환경설정)
// views 디렉토리에서 nunjucks파일을 찾게 되어있습니다.
// express: app --> express를 nunjucks에 연결하는 부분입니다.
// watch: true --> 템플릿 파일의 변경점을 감지하면 자동으로 새로고침 
nunjucks.configure('views', {
    express: app,
    watch: true,
})

sequelize.sync({force: false})
.then(() => {
     console.log('데이터베이스 연결 성공')
})
.catch( (err) => {
    console.error(err);
});
// 개발환경에서 http 요청을 logging
app.use(morgan('dev')); 
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false}));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/comments', commentsRouter);

// 서버에러를 다루는 함수
app.use((err, req, res, next) => {
res.locals.message = err.message;
res.locals.error = process.env.NODE_ENV !== 'production' ? err : {};
res.status(err.status || 500);
res.render('error') // 에러페이지 렌더링
});

app.listen(app.get('port'), () => {
    console.log(app.get('port'), '번 포트에서 대기중');
})

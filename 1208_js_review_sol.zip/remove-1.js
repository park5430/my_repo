const title = document.querySelector("h1");
// 문서에서 h1태그를 선택하여 변수에 저장
// 그 저장된 변수에 클릭 시 
// 아래와 같은 함수를 실행합니다. --> 지워주세요
title.addEventListener("click", () => {
  title.remove();
});